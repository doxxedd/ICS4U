package OOP;

import java.util.*;

public class ToyMain {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Toy toys[] = new Toy[3];

        Toy doll = new Toy("Doll", 19.98, 25.00);
        System.out.println("\nName: " + doll.getName());
        System.out.println("Cost: " + doll.getCost());
        System.out.println("Profit: " + doll.getProfit());

        Toy rubiksCube = new Toy("Rubiks Cube", 8.98, 19.97);
        System.out.println("\nProduct name: " + rubiksCube.getName());
        System.out.println("Product cost: " + rubiksCube.getCost());
        System.out.println("Product profit: " + rubiksCube.getProfit());

        Toy unoSE = new Toy("Uno Cards Special Edition", 1.55, 19.99);
        System.out.println("\nProduct name: " + unoSE.getName());
        System.out.println("Product cost: " + unoSE.getCost());
        System.out.println("Product profit: " + unoSE.getProfit());
    }
    /*
    *   A class is a blueprint and a template for an object. 
    *   Objects are created in classes and have states and behaviors (variables and methods)
    */
}
