package OOP;

public class Quarter extends Coin {
    
    @Override
    public double getValue() {
        return 0.25 ;
    }
}
