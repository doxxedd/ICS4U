package OOP;

public abstract class Coin {

    public double getValue() { return -1; }
}