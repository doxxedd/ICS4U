package OOP;

public class Nickel extends Coin {

    @Override
    public double getValue() {
        return 0.05 ;
    }
}