package OOP;

public class Dime extends Coin {

    @Override
    public double getValue() {
        return 0.10 ;
    }
}