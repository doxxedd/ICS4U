package OOP;

public class Toonie extends Coin {
    
    @Override
    public double getValue() {
        return 2.00 ;
    }
}
