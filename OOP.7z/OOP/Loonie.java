package OOP;

public class Loonie extends Coin {
    
    @Override
    public double getValue() {
        return 1.00 ;
    }
}
