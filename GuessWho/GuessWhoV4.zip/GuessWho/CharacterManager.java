package GuessWho;

import java.util.*;

public class CharacterManager {
        // Example:nameOfPerson;5;2;10;3;1;
    public static Person[] getCharactersInArray() throws Exception {

        var rawData = FileManager.ReadAllLines("characters.txt");

        ArrayList<Person> characters = new ArrayList<Person>();

        for (String personAttributesInString : rawData) {

            String[] nameAndAttributesList = personAttributesInString.split(";");

            List<Attribute> attributes = new ArrayList<Attribute>();

            for (int i = 1; i < nameAndAttributesList.length; i++) {
                attributes.add(Attribute.values()[Integer.parseInt(nameAndAttributesList[i])]);
            }

            characters.add(new Person(Attribute.valueOf(nameAndAttributesList[0].toUpperCase()), attributes));
        }

        // Converting the persons list to array before returning
        return characters.toArray(new Person[characters.size()]);
    }
}
