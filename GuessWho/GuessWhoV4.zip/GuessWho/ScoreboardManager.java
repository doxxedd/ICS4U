package GuessWho;

import java.util.*;

public class ScoreboardManager {

    private static String path = "scores.txt";

    //name;12:30;33
    public static ScoreRecord[] getScores() throws Exception {
        String[] lines = FileManager.ReadAllLines(path);
        List<ScoreRecord> scoreRecords = new ArrayList<ScoreRecord>();

        for (String line : lines) {
            String[] lineParts = line.split(";");
            scoreRecords.add(new ScoreRecord(lineParts[0], lineParts[1], Integer.parseInt(lineParts[2])));
        }

        return scoreRecords.toArray(new ScoreRecord[scoreRecords.size()]);
    }

    public static void addScore(ScoreRecord score) throws Exception{
        List<ScoreRecord> scoreRecords = new ArrayList<ScoreRecord>();

        for (ScoreRecord scoreRecord : getScores()) {
            scoreRecords.add(scoreRecord);
        }

        scoreRecords.add(score);

        SaveScores(scoreRecords.toArray(new ScoreRecord[scoreRecords.size()]));
    }

    private static void saveScores(ScoreRecord[] scoreRecords){
        List<String> lines = new ArrayList<String>();
        
        for (ScoreRecord sr : scoreRecords) {
            lines.add(sr.name + "" + sr.time + "" + sr.guessCount);
        }

        FileManager.WriteAllLines(path, lines.toArray(new String[lines.size()]));
    }

}