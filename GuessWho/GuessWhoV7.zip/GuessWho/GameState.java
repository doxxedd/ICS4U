/*
* Author: Daniel.D, Lucas.C, Lucas.S
* Date: 22-01-2021
* Description:
*/
package GuessWho;

//takes in the enumWinner and ScoreRecord and returns the updated status of the game
public class GameState {
    EnumWinner winner;
    ScoreRecord scoreRecord;
    Attribute AIsGuess;

    public GameState(Attribute AIsGuess, EnumWinner winner, ScoreRecord scoreRecord) {
        this.AIsGuess = AIsGuess;
        this.winner = winner;
        this.scoreRecord = scoreRecord;
    }
}
