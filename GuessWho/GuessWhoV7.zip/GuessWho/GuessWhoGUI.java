/*
* Author: Daniel.D, Lucas.C, Lucas.S
* Date: 25-01-2021
* Description:
*/
package GuessWho;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GuessWhoGUI extends JFrame implements ActionListener {
    private GuessWho gw;
    private int status;
    private int characterWidth = 135;
    private int characterHeight = 245;
    private String questionString;
    private String playerName;
    private int highScore;
    private int lastScore;

    public BoxLayout menuLayout;
    public FlowLayout frameLayout;
    public GridLayout characterLayout;
    public FlowLayout gameLayout;
    public BoxLayout consoleLayout;
    public BoxLayout questionLayout;
    public BoxLayout scoreLayout;
    public BoxLayout lossLayout;
    
    public JPanel characterPanel;
    public JPanel boardPanel;
    public JPanel menuPanel;
    public JPanel scorePanel;
    public JPanel questionPanel;
    public JPanel consolePanel;
    public JPanel saveScorePanel;
    public JPanel lossPanel;
    
    public JLabel[] characterLabel;
    public JLabel titleLabel;
    public JLabel highScoreLabel;
    public JLabel lastScoreLabel;
    public JLabel selectedImage;
    public JLabel selectedHeader;
    public JLabel consoleHeader;
    public JLabel consoleMessage;
    public JLabel newHighScoreLabel;
    public JLabel newLastScoreLabel;
    public JLabel winMessage;
    public JLabel lossMessage;

    public JButton confirmQuestion;
    public JButton playButton;
    public JButton saveButton;
    public JButton menuButton;
    public JButton menuButton2;
    
    //Pop up menu of all attributese
    public JComboBox<String> questionOption;
    
    public GuessWhoGUI(String playerName) throws Exception{
        //store flips and selected person
        //set the game to start up at the menu panel
        //set title size and etc. for the jframe
        this.playerName = playerName;
        
        status = 0;
        setTitle("Guess Who");
        setSize(1920, 1020);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameLayout = new FlowLayout();
        setLayout(frameLayout);

        //initiallize main panels
        //menu
        menuPanel = new JPanel();
        menuLayout = new BoxLayout(menuPanel, BoxLayout.Y_AXIS);
        menuPanel.setLayout(menuLayout);

        //board panel
        gameLayout = new FlowLayout();
        boardPanel = new JPanel(gameLayout);

        //score panel
        scorePanel = new JPanel();
        scoreLayout = new BoxLayout(scorePanel, BoxLayout.Y_AXIS);
        scorePanel.setLayout(scoreLayout);

        //loss panel
        lossPanel = new JPanel();
        lossLayout = new BoxLayout(lossPanel, BoxLayout.Y_AXIS);
        lossPanel.setLayout(lossLayout);

        resetGame();
        updateFrame();
    }

    public void updateFrame(){
        //call function to panel swap or refresh panel according to status
        if(status == 0) {
            displayMenu();
        }
        else if(status == 1) {
            displayBoard();
        }
        else if(status == 2){
            displayScore();
        }
        else if(status == 3){
            displayLoss();
        }
        else {
            System.out.println("An error has occurred");
        }
        setVisible(true);
    }

    public void displayMenu(){
        //main menu panel
        titleLabel = new JLabel("Guess Who");
        //TODO
        highScoreLabel = new JLabel("High score: " + highScore);
        lastScoreLabel = new JLabel("Last score: " + lastScore);
        playButton = new JButton("Play");
        playButton.addActionListener(this);
        titleLabel.setFont(new Font("Courier", Font.BOLD,80));
        playButton.setFont(new Font("Courier", Font.BOLD,80));
        highScoreLabel.setFont(new Font("Courier", Font.BOLD,40));
        lastScoreLabel.setFont(new Font("Courier", Font.BOLD,40));
        menuPanel.add(titleLabel);
        menuPanel.add(playButton);
        menuPanel.add(highScoreLabel);
        menuPanel.add(lastScoreLabel);
        
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        highScoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        lastScoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        playButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(menuPanel);

        menuPanel.setVisible(true);
    }

    public void displayBoard() {
        //board/game panel
        boardPanel.removeAll();

        characterLayout = new GridLayout(4,6);
        questionPanel = new JPanel();
        questionLayout = new BoxLayout(questionPanel, BoxLayout.Y_AXIS);
        questionPanel.setLayout(questionLayout);
        characterPanel = new JPanel(characterLayout);
        characterPanel.setSize(1220, 980);
        consolePanel = new JPanel();
        consoleLayout = new BoxLayout(consolePanel, BoxLayout.Y_AXIS);
        consolePanel.setLayout(consoleLayout);

        //Use characters array to import images of active characters
        characterLabel = new JLabel[gw.getBoardsForUI()[0].getFlips().length];

        String characterName;
        ImageIcon tempImageIcon;
        Image tempImage;
        Image modifiedImage;

        for(int i = 0; i < gw.getBoardsForUI()[0].getFlips().length; i ++){
            if(gw.getBoardsForUI()[0].getFlips()[i].getIsActive()){
                characterName = gw.getBoardsForUI()[0].getFlips()[i].getPerson().getName().toString();
                characterName = characterName.substring(0,1).toUpperCase() + characterName.substring(1).toLowerCase();
                tempImageIcon = new ImageIcon("GuessWhoImages/"+characterName+".jpg");
            }
            else{
                tempImageIcon = new ImageIcon("GuessWhoImages/Cardback.jpg");
            }
            tempImage = tempImageIcon.getImage();
            modifiedImage = tempImage.getScaledInstance(characterWidth, characterHeight, java.awt.Image.SCALE_SMOOTH);
            tempImageIcon = new ImageIcon(modifiedImage);
            characterLabel[i] = new JLabel(tempImageIcon);          
            characterPanel.add(characterLabel[i]);
        }

        confirmQuestion = new JButton("Ask question");
        confirmQuestion.addActionListener(this);
        confirmQuestion.setFont(new Font("Courier", Font.BOLD,40));
        confirmQuestion.setAlignmentX(Component.CENTER_ALIGNMENT);

        //Pop up menu for player to selected question
        String[] options = new String[45];
        int counter = 0;
        for (Attribute attribute : Attribute.values()) { 
            options[counter] = EnumConverter.enumToString(attribute);
            counter++;
            if(counter > 44) break;
        }
        questionOption = new JComboBox<>(options);
        questionOption.setFont(new Font("Courier", Font.BOLD,20));
        questionOption.setPreferredSize(new Dimension(135, 40));
        questionOption.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        questionPanel.add(questionOption);
        questionPanel.add(confirmQuestion);

        selectedHeader = new JLabel("Selected character");
        selectedImage = new JLabel(new ImageIcon("GuessWhoImages/"+gw.getBoardsForUI()[0].getSelectedPerson()+".jpg"));
        selectedImage.setAlignmentX(Component.CENTER_ALIGNMENT);

        selectedHeader.setFont(new Font("Courier", Font.BOLD,30));
        selectedHeader.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        questionPanel.add(selectedHeader);
        questionPanel.add(selectedImage);

        consoleHeader = new JLabel(" Console");
        consoleHeader.setFont(new Font("Courier", Font.BOLD,40));
        //consoleHeader.setPreferredSize(new Dimension(780, 60));
        if(questionString.equals("")){
            consoleMessage = new JLabel("  Your selected character is " + EnumConverter.enumToString(gw.getBoardsForUI()[0].getSelectedPerson()));
        }
        else {
            consoleMessage = new JLabel("  You asked for " + questionString);
        }
        consoleMessage.setFont(new Font("Courier", Font.BOLD,20));
        //consoleMessage.setPreferredSize(new Dimension(780, 920));
        consolePanel.setPreferredSize(new Dimension(820, 980));
        consolePanel.setBackground(Color.LIGHT_GRAY);

        consolePanel.add(consoleHeader);
        consolePanel.add(consoleMessage);

        boardPanel.add(characterPanel);
        boardPanel.add(questionPanel);
        boardPanel.add(consolePanel);
        add(boardPanel);

        boardPanel.setVisible(true);
    }

    public void displayScore() {
        //display score panel, if you win
        winMessage = new JLabel("Good job you won");
        winMessage.setFont(new Font("Courier", Font.BOLD,80));
        winMessage.setForeground(Color.GREEN);
        winMessage.setAlignmentX(Component.CENTER_ALIGNMENT);
        //TODO
        newHighScoreLabel = new JLabel("New highscore: " + highScore);
        newHighScoreLabel.setFont(new Font("Courier", Font.BOLD,40));
        newHighScoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        newLastScoreLabel = new JLabel("Your score: " + lastScore);
        newLastScoreLabel.setFont(new Font("Courier", Font.BOLD,40));
        newLastScoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        saveButton = new JButton("Save score");
        saveButton.setFont(new Font("Courier", Font.BOLD,40));
        saveButton.addActionListener(this);
        saveButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        menuButton = new JButton("Back to menu");
        menuButton.setFont(new Font("Courier", Font.BOLD,40));
        menuButton.addActionListener(this);
        menuButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        scorePanel.add(winMessage);
        scorePanel.add(newHighScoreLabel);
        scorePanel.add(newLastScoreLabel);
        scorePanel.add(saveButton);
        scorePanel.add(menuButton);

        add(scorePanel);
        
        scorePanel.setVisible(true);
    }

    public void displayLoss() {
        //display loss panel, if you lose

        lossMessage = new JLabel("Good try, you lost");
        lossMessage.setForeground(Color.RED);
        lossMessage.setFont(new Font("Courier", Font.BOLD,40));
        lossMessage.setAlignmentX(Component.CENTER_ALIGNMENT);

        menuButton = new JButton("Back to menu");
        menuButton.setFont(new Font("Courier", Font.BOLD,40));
        menuButton.addActionListener(this);
        menuButton.setAlignmentX(Component.CENTER_ALIGNMENT);


        lossPanel.add(lossMessage);
        lossPanel.add(menuButton);

        add(lossPanel);
        lossPanel.setVisible(true);
    }

    public void actionPerformed(ActionEvent event){
        //store the button that was clicked
        String button = event.getActionCommand();
        if(button.equals("Play")){
            //switch from main menu to board panel
            status = 1;
            menuPanel.setVisible(false);
            updateFrame();
        }
        else if(button.equals("Ask question")){
            //Need work: We got the attribute they are asking for, now convert this string version of attribute to an enum
            //eg. convert from "glasses and hat" to "GLASSES_AND_HAT"
            questionString = (String)questionOption.getSelectedItem();
            //Need work: use updateCharacters(Flip[] flips) to update board after AI questioning
            //Need work: update console message to playerName asked for attribute here or something more user friendly
            //TODO: also display the response to the players question and what the AI asks
            
            updateFrame();
        }
        else if(button.equals("Save score")){
            //save score
            //replace zeros high score and lastscore, see updateScores function for more
            //TODO:
            status = 0;
            scorePanel.setVisible(false);
            setVisible(true);
            updateFrame();
        }
        else if(button.equals("Back to menu")){
            //go back to menu from loss or victory screen without saving score
            status = 0;
            scorePanel.setVisible(false);
            lossPanel.setVisible(false);
            updateFrame();
        }
    }

    public void resetGame() throws Exception{
        gw = new GuessWho(playerName);
        highScore = ScoreboardManager.getLeastGuesses();
        lastScore = ScoreboardManager.getScores()[ScoreboardManager.getScores().length-1].guessCount;
        questionString = "";
    }
}
