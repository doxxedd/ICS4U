/*
* Author: Daniel.D, Lucas.C, Lucas.S
* Date: 12-01-2021
* Description:
*/
package GuessWho;

import java.util.*;

public class GuessWho {
    //declare board arrays and class level instances
    private Board[] boards = new Board[2];
    private AI ai = new AI();
    private Timer timer;
    private String playerName;
    private int guessCount = 0;

    private int activeBoard = 0; // Player 0, AI 1

    Random rand = new Random(); //new random instance 

    //GuessWho instantiates the boards
    public GuessWho(String playerName) throws Exception {

        this.playerName = playerName;

        timer = new Timer();

        Random randGen = new Random();

        Person[] characters = CharacterManager.getCharactersInArray();

        boards[0] = new Board(characters, Attribute.values()[randGen.nextInt(24) + 21]);

        // Shuffling of characters on the boards starts
        List<Person> charactersInList = Arrays.asList(characters);
        Collections.shuffle(charactersInList);
        characters = charactersInList.toArray(characters);
        // Shuffling of characters on the boards starts ends

        boards[1] = new Board(characters, Attribute.values()[randGen.nextInt(24) + 21]); 
    }

    // Getter method of boards to be used with GUI
    public Board[] getBoardsForUI(){
        return boards;
    }

    // Call this method when asking a question. Determines the winner, adds scores to file, updates the status of flips based on question.
    public GameState questioning(Attribute attribute) throws Exception {

        if (attribute.ordinal() > 20) {
            if (activeBoard == 0) {
                if (boards[1].getSelectedPerson() == attribute) {
                    ScoreboardManager.addScore(new ScoreRecord(playerName, timer.getElapsedTime(), guessCount));
                    // TODO: Game end with player winning
                    return new GameState(Attribute.NOTSET, EnumWinner.PLAYER, new ScoreRecord(playerName, timer.getElapsedTime(), guessCount));
                }
                else{
                    for (Flip f : boards[0].getFlips()) {
                        if(f.getPerson().getName() == attribute){
                            f.flipDown();
                            break;
                        }
                    }
                }
            }
            else{
                if (boards[0].getSelectedPerson() == attribute) {
                    // TODO: Game end with AI winning
                    return new GameState(attribute, EnumWinner.AI, null);
                }
                else{
                    for (Flip f : boards[1].getFlips()) {
                        if(f.getPerson().getName() == attribute){
                            f.flipDown();
                            break;
                        }
                    }
                }
            }
            return new GameState(attribute, EnumWinner.NONE, null);
        }

        boards[activeBoard].flipDownPeopleWithoutAttributeAsked(attribute);

        // Players swapping turns
        if (activeBoard == 0) {
            guessCount++;
            activeBoard = 1;
        }
        else{
            activeBoard = 0;
        }

        // Might be a good idea to call the AI for question as well if this was the players turn
        if (activeBoard == 0) {
            questioning(ai.getAttribute(boards[1]));
        }
        return new GameState(attribute, EnumWinner.NONE, null);
        
    }
}