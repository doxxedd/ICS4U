package GuessWho;

public class Question {
    private String guess = "Invalid question";

    //Quetions constructors 
    //blush constructor
    public Question(enumBlush blush) {
        if(blush == enumBlush.HAS_BLUSH) {
            guess = "Does your character have blush?";
        }
        else if(blush == enumBlush.NO_BLUSH) {
            guess = "Does your character not have blush?";
        }
    }
   
    //accessories constructor
    public Question(enumAccessories accessories) {
        if(accessories == enumAccessories.NONE) {
            guess = "Does your character have no accessories?";
        }
        else if(accessories == enumAccessories.GLASSES) {
            guess = "Does your character have glasses?";
        }
        else if(accessories == enumAccessories.HAT) {
            guess = "Does your character have a hat?";
        }
        else if(accessories == enumAccessories.EARINGS) {
            guess = "Does your character have earings?";
        }
        else if(accessories == enumAccessories.HAT_AND_GLASSES) {
            guess = "Does your character have hat and glasses?";
        }
    }
   
    //eyecolor constructor
    public Question(enumEyeColor eyeColor) {
        if(eyeColor == enumEyeColor.BROWN) {
            guess = "Does your character have brown eyes?";
        }
        else if(eyeColor == enumEyeColor.BLUE) {
            guess = "Does your character have blue eyes?";
        }
    }
    
    //haircolor constructor
    public Question(enumHairColor hairColor) {
        if(hairColor == enumHairColor.BLACK) {
            guess = "Does your character have black hair?";
        }
        else if (hairColor == enumHairColor.YELLOW) {
            guess = "Does your character have Yellow hair?";
        }
        else if (hairColor == enumHairColor.WHITE) {
            guess = "Does your character have White hair?";
        }
        else if (hairColor == enumHairColor.ORANGE){
            guess = "Does your character have Orage hair?";
        }
        else if (hairColor == enumHairColor.BROWN){
            guess = "Does your character have Brown hair?";
        }
        else if ((hairColor == enumHairColor.NOTSET)){
            guess = "Does your character have no hair?";
        }
    }
    
    //lipsize constructor  
    public Question(enumLipSize lipSize) {
        if (lipSize == enumLipSize.BIG) {
            guess = "Does your character have big lips?";
        }
        else if (lipSize == enumLipSize.SMALL) {
            guess = "Does your character have small lips?";
        }
    }
    
    //gender constructor
    public Question(enumGender gender) {
        if (gender == enumGender.MALE) {
            guess = "Is your character male?";
        } 
        else if (gender == enumGender.FEMALE) {
            guess = "Is your character female?";
        }
    }
    
    //hairtype constructor
    public Question(enumHairType hairType) {
        if (hairType == enumHairType.CURLY) {
            guess = "Does your character have curly hair?";
        }
        else if (hairType == enumHairType.STRAIGHT) {
            guess = "Does your character have straight hair?";
        }
        else if (hairType == enumHairType.LONG_AND_STRAIGHT) {
            guess = "Does your character have long straight hair?";
        }
        else if (hairType == enumHairType.SHORT_AND_STRAIGHT) {
            guess = "Does your character have short straight hair?";
        }
        else if (hairType == enumHairType.PARTIALLY_BALD) {
            guess = "Is your character partially bald?";
        }
    }
    
    //facialHair constructor
    public Question (enumFacialHair facialHair) {
        if (facialHair == enumFacialHair.BEARD) {
            guess = "Does your character have a beard?";
        } else if (facialHair == enumFacialHair.MUSTACHE) {
            guess = "Does your character have a mustache?";
        } else if (facialHair == enumFacialHair.MUSTACHE_AND_BEARD) {
            guess = "Does your character have both a mustache and beard";
        }
    }

    public String getQuestion() {
        return guess;
    }
}
