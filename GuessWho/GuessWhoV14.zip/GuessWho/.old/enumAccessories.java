package GuessWho;

enum enumAccessories {
    GLASSES, 
    HAT,
    EARINGS,
    HAT_AND_GLASSES,
    NONE, 
    NOTSET;
}
