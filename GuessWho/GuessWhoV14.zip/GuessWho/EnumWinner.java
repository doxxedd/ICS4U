/*
* Author: Daniel.D
* Date: 25-01-2021
* Description: Enum class representing which player won
*/
package GuessWho;

//an enum that represents who won
enum EnumWinner {
    PLAYER,
    AI,
    NONE;
}
