/*
* Author: Daniel.D, Lucas.C, Lucas.S
* Date: 26-01-2021
* Description: Enum class representing which player won
*/
package GuessWho;

//an enum that represents who won
enum EnumWinner {
    PLAYER,
    AI,
    NONE;
}
