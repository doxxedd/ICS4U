package GuessWho;

import java.util.*;
import java.lang.Math;

public class GuessWho {
    //declare Arrays
    private Board[] boards = new Board[2];
    private AI ai = new AI();
    private Timer timer;
    private String playerName;
    private int guessCount = 0;

    // Added on 24
    private int activeBoard = 0; // Player 0, AI 1

    Random rand = new Random();

    public GuessWho(String playerName) throws Exception {

        this.playerName = playerName;

        timer = new Timer();

        Random randGen = new Random();

        Person[] characters = CharacterManager.getCharactersInArray();

        boards[0] = new Board(characters, Attribute.values()[randGen.nextInt(24) + 21]);

        // Shuffling starts
        List<Person> charactersInList = Arrays.asList(characters);
        Collections.shuffle(charactersInList);
        characters = charactersInList.toArray(characters);
        // Shuffling ends

        boards[1] = new Board(characters, Attribute.values()[randGen.nextInt(24) + 21]); 
    }

    // Added on 24

    public Board[] getBoardsForUI(){
        return boards;
    }

    public void questioning(Attribute attribute) throws Exception {

        if (attribute.ordinal() > 20) {
            if (activeBoard == 0) {
                if (boards[1].getSelectedPerson() == attribute) {
                    ScoreboardManager.addScore(new ScoreRecord(playerName, timer.getElapsedTime(), guessCount));
                    // TODO: Game end with player winning
                }
                else{
                    for (Flip f : boards[0].getFlips()) {
                        if(f.getPerson().getName() == attribute){
                            f.flipDown();
                            break;
                        }
                    }
                }
            }
            else{
                if (boards[0].getSelectedPerson() == attribute) {
                    // TODO: Game end with AI winning
                }
                else{
                    for (Flip f : boards[1].getFlips()) {
                        if(f.getPerson().getName() == attribute){
                            f.flipDown();
                            break;
                        }
                    }
                }
            }
            return;
        }

        boards[activeBoard].flipDownPeopleWithoutAttribute(attribute);

        // Players swapping turns
        if (activeBoard == 0) {
            guessCount++;
            activeBoard = 1;
        }
        else{
            activeBoard = 0;
        }

        // Might be a good idea to call the AI for question as well if this was the players turn

        if (activeBoard != 0) {
            return;
        }

        //questioning([MethodCallingThatAsksTheAIForAnAttributeAsAReturn]]);
        questioning(ai.getAttribute(boards[1]));
    }
}