package GuessWho;

import java.io.*;
import java.util.*;

public class FileManager{

    public static String[] ReadAllLines(String path) throws Exception {

        List<String> lines = new ArrayList<String>();

        File file = new File(path);
        Scanner fileInput = new Scanner(file);

        while(fileInput.hasNext()) {
            lines.add(fileInput.nextLine());
        }

        fileInput.close();

        return lines.toArray(new String[lines.size()]);
    
    }

    public static void WriteAllLines(String path, String[] lines) throws Exception {
        PrintWriter output = new PrintWriter(path);

        for (String line : lines) {
            output.println(line);
        }
        
        output.close();
    }
}