package GuessWho;

import java.awt.*;
import javax.swing.*;

public class GUI extends JFrame {
    public JPanel panel1;
    public JLabel label1;
    public JButton button1;
    public JTextField textField1;

    public GUI() {
        setTitle("Guess Who");
        setSize(1000, 700);
        setResizable(false);

        panel1 = new JPanel();

        label1 = new JLabel("Hello");

        button1 = new JButton("Button");

        textField1 = new JTextField();
        
    }
}
