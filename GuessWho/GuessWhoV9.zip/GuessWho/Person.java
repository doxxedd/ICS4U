/*
 * File Name: Person.java
 * Authors: Lucas.C, Lucas.S, Daniel.D
 * Date: 22 - 01 - 2021
 * Description: Functioning person class that stores attributes of a GuessWho character
 * Teacher: Ms. Andreghetti
 */

package GuessWho;

//import javax.swing.*;
import java.util.*;

public class Person {

    private Attribute name;
    private List<Attribute> attributes = new ArrayList<Attribute>();

    public Person(Attribute name, List<Attribute> attributes) {
        this.name = name;
        this.attributes = attributes;
    }

    public boolean hasAttribute(Attribute attribute){
        for (Attribute a : attributes) {
            if (a == attribute) {
                return true;
            }
        }
        return false;
    }

    public List<Attribute> getAttributes(){
        return attributes;
    }

    public Attribute getName(){
        return name;
    }
    
}