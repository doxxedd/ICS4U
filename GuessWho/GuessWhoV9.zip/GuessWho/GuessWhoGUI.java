package GuessWho;

import java.awt.*;
import java.awt.event.*;

import javax.lang.model.util.ElementScanner14;
import javax.swing.*;

public class GuessWhoGUI extends JFrame implements ActionListener {
    private GuessWho gw;
    private int status;
    private int characterWidth = 135;
    private int characterHeight = 245;
    private String questionString;
    private String playerName;
    private int highScore;
    private int lastScore;
    private Attribute aiQuestion;

    public BoxLayout menuLayout;
    public FlowLayout frameLayout;
    public GridLayout characterLayout;
    public FlowLayout gameLayout;
    public BoxLayout consoleLayout;
    public BoxLayout questionLayout;
    public BoxLayout scoreLayout;
    public BoxLayout lossLayout;
    
    private JPanel characterPanel;
    private JPanel boardPanel;
    private JPanel menuPanel;
    private JPanel scorePanel;
    private JPanel questionPanel;
    private JPanel consolePanel;
    private JPanel saveScorePanel;
    private JPanel lossPanel;
    
    public JLabel[] characterLabel;
    public JLabel titleLabel;
    public JLabel highScoreLabel;
    public JLabel lastScoreLabel;
    public JLabel selectedImage;
    public JLabel selectedHeader;
    public JLabel consoleHeader;
    public JLabel consoleMessage1;
    public JLabel consoleMessage2;
    public JLabel newHighScoreLabel;
    public JLabel newLastScoreLabel;
    public JLabel winMessage;
    public JLabel lossMessage;

    public JButton confirmQuestion;
    public JButton playButton;
    public JButton saveButton;
    public JButton menuButton;
    public JButton menuButton2;
    
    public JComboBox<String> questionOption;
    
    public GuessWhoGUI(String playerName) throws Exception{
        //store flips and selected person
        //set the game to start up at the menu panel
        //set title size and etc. for the jframe
        this.playerName = playerName;
        
        status = 0;
        setTitle("Guess Who");
        setSize(1920, 1020);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameLayout = new FlowLayout();
        setLayout(frameLayout);

        //initiallize main panels
        //menu
        menuPanel = new JPanel();
        menuLayout = new BoxLayout(menuPanel, BoxLayout.Y_AXIS);
        menuPanel.setLayout(menuLayout);

        //board panel
        gameLayout = new FlowLayout();
        boardPanel = new JPanel(gameLayout);

        //score panel
        scorePanel = new JPanel();
        scoreLayout = new BoxLayout(scorePanel, BoxLayout.Y_AXIS);
        scorePanel.setLayout(scoreLayout);

        //loss panel
        lossPanel = new JPanel();
        lossLayout = new BoxLayout(lossPanel, BoxLayout.Y_AXIS);
        lossPanel.setLayout(lossLayout);

        resetGame();
        updateFrame();
    }

    public void updateFrame(){
        //call function to panel swap or refresh panel according to status
        if(status == 0) {
            displayMenu();
        }
        else if(status == 1) {
            displayBoard();
        }
        else if(status == 2){
            displayScore();
        }
        else if(status == 3){
            displayLoss();
        }
        else {
            System.out.println("An error has occured");
        }
        setVisible(true);
    }

    public void displayMenu(){
        //main menu panel
        titleLabel = new JLabel("Guess Who");
        //TODO
        highScoreLabel = new JLabel("High score: " + highScore);
        lastScoreLabel = new JLabel("Last score: " + lastScore);
        playButton = new JButton("Play");
        playButton.addActionListener(this);
        titleLabel.setFont(new Font("Courier", Font.BOLD,80));
        playButton.setFont(new Font("Courier", Font.BOLD,80));
        highScoreLabel.setFont(new Font("Courier", Font.BOLD,40));
        lastScoreLabel.setFont(new Font("Courier", Font.BOLD,40));
        menuPanel.add(titleLabel);
        menuPanel.add(playButton);
        menuPanel.add(highScoreLabel);
        menuPanel.add(lastScoreLabel);
        
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        highScoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        lastScoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        playButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(menuPanel);

        menuPanel.setVisible(true);
    }

    public void displayBoard() {
        //board/game panel
        boardPanel.removeAll();

        characterLayout = new GridLayout(4,6);
        questionPanel = new JPanel();
        questionLayout = new BoxLayout(questionPanel, BoxLayout.Y_AXIS);
        questionPanel.setLayout(questionLayout);
        characterPanel = new JPanel(characterLayout);
        characterPanel.setSize(1220, 980);
        consolePanel = new JPanel();
        consoleLayout = new BoxLayout(consolePanel, BoxLayout.Y_AXIS);
        consolePanel.setLayout(consoleLayout);

        //Use characters array to import images of active characters
        characterLabel = new JLabel[gw.getBoardsForUI()[0].getFlips().length];

        String characterName;
        ImageIcon tempImageIcon;
        Image tempImage;
        Image modifiedImage;

        for(int i = 0; i < gw.getBoardsForUI()[0].getFlips().length; i ++){
            characterName = gw.getBoardsForUI()[0].getFlips()[i].getPerson().getName().toString();
            characterName = characterName.substring(0,1).toUpperCase() + characterName.substring(1).toLowerCase();
            if(gw.getBoardsForUI()[0].getFlips()[i].getIsActive()){
                //characterName = gw.getBoardsForUI()[0].getFlips()[i].getPerson().getName().toString();
                //characterName = characterName.substring(0,1).toUpperCase() + characterName.substring(1).toLowerCase();
                tempImageIcon = new ImageIcon("GuessWhoImages/"+characterName+".jpg");
            }
            else{
                tempImageIcon = new ImageIcon("GuessWhoImages/Cardback.jpg");
            }
            tempImage = tempImageIcon.getImage();
            modifiedImage = tempImage.getScaledInstance(characterWidth, characterHeight, java.awt.Image.SCALE_SMOOTH);
            tempImageIcon = new ImageIcon(modifiedImage);
            characterLabel[i] = new JLabel(tempImageIcon);          
            characterPanel.add(characterLabel[i]);
        }

        confirmQuestion = new JButton("Ask question");
        confirmQuestion.addActionListener(
            new ActionListener() {
            public void actionPerformed(ActionEvent e) 
            {
                try {
                    //TODO: this is what the program does when you press ask question
                    //Reminder: This part should include the ai questioning, calculating how many flips are up for the ai, what happens when you win or lose
                    //If you want to win, simply set status = 2 and set status = 3 for lose
                    questionString = (String)questionOption.getSelectedItem();
                    //gw.questioning(EnumConverter.stringToEnum(questionString);
                    //aiQuestion = gw.questioning(EnumConverter.stringToEnum(questionString)).AIsGuess; <- Commented it yesterday

                    // Added yesterday --
                    var result = gw.questioning(EnumConverter.stringToEnum(questionString));
                    if (result.winner == EnumWinner.PLAYER) {
                        System.out.println("The player won with a score:" + result.scoreRecord.name + ": " + result.scoreRecord.guessCount + " with time:" + result.scoreRecord.time);
                    }
                    else if(result.winner == EnumWinner.AI){
                        System.out.println("The AI won.");
                        aiQuestion = result.AIsGuess;
                    }
                    else{
                        aiQuestion = result.AIsGuess;
                    }
                    // --
                }
                catch(Exception ex){
                    System.out.println("An error has occurred");
                }
                updateFrame();
            }
        });

        confirmQuestion.setFont(new Font("Courier", Font.BOLD,40));
        confirmQuestion.setAlignmentX(Component.CENTER_ALIGNMENT);

        //Pop up menu for player to selected question
        String[] options = new String[45];
        int counter = 0;
        for (Attribute attribute : Attribute.values()) { 
            if(counter < 21) options[counter] = EnumConverter.enumToString(attribute).toLowerCase();
            else options[counter] = EnumConverter.enumToString(attribute);
            counter++;
            if(counter > 44) break;
        }
        questionOption = new JComboBox<>(options);
        questionOption.setFont(new Font("Courier", Font.BOLD,20));
        questionOption.setPreferredSize(new Dimension(135, 40));
        questionOption.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        questionPanel.add(questionOption);
        questionPanel.add(confirmQuestion);

        selectedHeader = new JLabel("Selected character");
        selectedImage = new JLabel(new ImageIcon("GuessWhoImages/"+gw.getBoardsForUI()[0].getSelectedPerson()+".jpg"));
        selectedImage.setAlignmentX(Component.CENTER_ALIGNMENT);

        selectedHeader.setFont(new Font("Courier", Font.BOLD,30));
        selectedHeader.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        questionPanel.add(selectedHeader);
        questionPanel.add(selectedImage);

        consoleHeader = new JLabel(" Game Director");
        consoleHeader.setFont(new Font("Courier", Font.BOLD,40));
        //consoleHeader.setPreferredSize(new Dimension(780, 60));
        if(questionString.equals("")){
            consoleMessage1 = new JLabel("  Your selected character is " + EnumConverter.enumToString(gw.getBoardsForUI()[0].getSelectedPerson()) + "\n");
        }
        else {
            consoleMessage1 = new JLabel("  You asked for " + questionString);
        }

        if(aiQuestion != null) {
            if(aiQuestion.ordinal() <21) {
                consoleMessage2 = new JLabel("  The AI asked for " + EnumConverter.enumToString(aiQuestion).toLowerCase());
            }
            else {
                consoleMessage2 = new JLabel("  The AI asked if your character is " + EnumConverter.enumToString(aiQuestion));
            }
        }
        else consoleMessage2 = new JLabel();
        
        consoleMessage1.setFont(new Font("Courier", Font.BOLD,20));
        consoleMessage2.setFont(new Font("Courier", Font.BOLD,20));
        //consoleMessage.setPreferredSize(new Dimension(780, 920));
        consolePanel.setPreferredSize(new Dimension(820, 980));
        consolePanel.setBackground(Color.LIGHT_GRAY);

        consolePanel.add(consoleHeader);
        consolePanel.add(consoleMessage1);
        consolePanel.add(consoleMessage2);

        boardPanel.add(characterPanel);
        boardPanel.add(questionPanel);
        boardPanel.add(consolePanel);
        add(boardPanel);

        boardPanel.setVisible(true);
    }

    public void displayScore() {
        //display score panel, if you win
        winMessage = new JLabel("Good job you won");
        winMessage.setFont(new Font("Courier", Font.BOLD,80));
        winMessage.setForeground(Color.GREEN);
        winMessage.setAlignmentX(Component.CENTER_ALIGNMENT);
        //TODO
        newHighScoreLabel = new JLabel("New highscore: " + highScore);
        newHighScoreLabel.setFont(new Font("Courier", Font.BOLD,40));
        newHighScoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        newLastScoreLabel = new JLabel("Your score: " + lastScore);
        newLastScoreLabel.setFont(new Font("Courier", Font.BOLD,40));
        newLastScoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        saveButton = new JButton("Save score");
        saveButton.setFont(new Font("Courier", Font.BOLD,40));
        saveButton.addActionListener(this);
        saveButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        menuButton = new JButton("Back to menu");
        menuButton.setFont(new Font("Courier", Font.BOLD,40));
        menuButton.addActionListener(this);
        menuButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        scorePanel.add(winMessage);
        scorePanel.add(newHighScoreLabel);
        scorePanel.add(newLastScoreLabel);
        scorePanel.add(saveButton);
        scorePanel.add(menuButton);

        add(scorePanel);
        
        scorePanel.setVisible(true);
    }

    public void displayLoss() {
        //display loss panel, if you lose

        lossMessage = new JLabel("Good try, you lost");
        lossMessage.setForeground(Color.RED);
        lossMessage.setFont(new Font("Courier", Font.BOLD,40));
        lossMessage.setAlignmentX(Component.CENTER_ALIGNMENT);

        menuButton = new JButton("Back to menu");
        menuButton.setFont(new Font("Courier", Font.BOLD,40));
        menuButton.addActionListener(this);
        menuButton.setAlignmentX(Component.CENTER_ALIGNMENT);


        lossPanel.add(lossMessage);
        lossPanel.add(menuButton);

        add(lossPanel);
        lossPanel.setVisible(true);
    }

    public void actionPerformed(ActionEvent event){
        //store the button that was clicked
        String button = event.getActionCommand();
        if(button.equals("Play")){
            //switch from main menu to board panel
            status = 1;
            menuPanel.setVisible(false);
            updateFrame();
        }
        else if(button.equals("Save score")){
            //TODO: Save score, this is executed when you press savescore on the win screen
            status = 0;
            scorePanel.setVisible(false);
            setVisible(true);
            updateFrame();
        }
        else if(button.equals("Back to menu")){
            //go back to menu from loss or victory screen without saving score
            status = 0;
            scorePanel.setVisible(false);
            lossPanel.setVisible(false);
            updateFrame();
        }
    }

    public void resetGame() throws Exception{
        gw = new GuessWho(playerName);
        highScore = ScoreboardManager.getLeastGuesses();
        var scores = ScoreboardManager.getScores();
        if(scores.length > 0){
            lastScore = scores[scores.length-1].guessCount; //Fixed cuz u didn't check if the scores did have any record or not
        }
        else{
            lastScore = -1; // TODO: That happens when there are no scores yet, u do whatever you want with it :)
        }
        questionString = "";
        aiQuestion = null;
    }
}
