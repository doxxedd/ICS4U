package GuessWho;

public class Main {
    public static void main(String[] args) {
        var gw = new GuessWho();
        System.out.println("asfd");
    }
}
