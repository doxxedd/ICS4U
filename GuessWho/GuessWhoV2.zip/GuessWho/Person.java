/*
 * File Name: Person.java
 * Authors: Lucas.C, Lucas.S, Daniel.D
 * Date: 22 - 01 - 2021
 * Description: Functioning person class that stores attributes of a GuessWho character
 * Teacher: Ms. Andreghetti
 */

package GuessWho;

//import javax.swing.*;
import java.util.*;

public class Person {

    private String name;
    private List<Attribute> attributes = new ArrayList<Attribute>();

    public Person(String name, List<Attribute> attributes) {
        this.name = name;
        this.attributes = attributes;
    }

    public boolean hasAttribute(Attribute attribute){
        for (Attribute a : attributes) {
            if (a == attribute) {
                return true;
            }
        }
        return false;
    }

    public List<Attribute> getAttributes(){
        return attributes;
    }
    
    // //Initialling all attributes of Person
    // private String name;
    //
    // private ImageIcon image; 
    // private enumBlush blush = enumBlush.NOTSET;
    // private enumHairColor hairColor = enumHairColor.NOTSET;
    // private enumFacialHair facialHair = enumFacialHair.NOTSET;
    // private enumAccessories accessories = enumAccessories.NOTSET;
    // private enumEyeColor eyeColor = enumEyeColor.NOTSET;
    // private enumLipSize lipSize = enumLipSize.NOTSET;
    // private enumHairType hairType = enumHairType.NOTSET;
    // private enumGender gender = enumGender.NOTSET;

    // //Constructor for Person
    // public Person (String name, 
    // enumAccessories accessories, 
    // enumBlush blush,
    // enumEyeColor eyeColor,
    // enumFacialHair facialHair, 
    // enumGender gender, 
    // enumHairColor hairColor, 
    // enumHairType hairType, 
    // enumLipSize lipSize
    // ) {
    //     this.name = name;
    //     this.image = new ImageIcon("GuessWhoImages/"+name+".jpg");
    //     this.blush = blush;
    //     this.hairColor = hairColor;
    //     this.facialHair = facialHair;
    //     this.accessories = accessories;
    //     this.eyeColor = eyeColor;
    //     this.lipSize = lipSize;
    //     this.hairType = hairType;
    //     this.gender = gender;
    // }

    // //Getters for each attribute of Person
    // public String getName() {
    //     return name;
    // }

    // public void setName (String newName) {
    //     this.name = newName;
    // }

    // public enumBlush getBlush() {
    //     return blush;
    // }
    
    // public enumAccessories getAccessories() {
    //     return accessories;
    // }
    
    // public enumEyeColor getEyeColor() {
    //     return eyeColor;
    // }
    
    // public enumFacialHair getFacialHair() {
    //     return facialHair;
    // }

    // public enumHairColor getHairColor() {
    //     return hairColor;
    // }

    // public enumGender getGender() {
    //     return gender;
    // }
    
    // public enumLipSize getLipSize () {
    //     return lipSize;
    // }

    // public enumHairType getHairType() {
    //     return hairType;
    // }

}