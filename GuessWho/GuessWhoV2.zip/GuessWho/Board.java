package GuessWho;

public class Board {

    private Flip[] flips = new Flip[24];
    
    public Board(Person[] characters) {

        for(int i = 0; i < 24; i ++) {
            flips[i] = new Flip(characters[i]);
        }
    }


    // Added on 24
    public void FlipDownPeopleWithoutAttribute(Attribute attribute){
        for (Flip f : flips) {
            f.flipDownIfHasAttribute(attribute);
        }
    }

    public Flip[] getFlips(){
        return flips;
    }
}