package GuessWho;

import java.util.*;

public class GuessWho {
    //declare Arrays
    private Board[] boards;
    private AI ai = new AI();
    private FileManager fm = new FileManager();

    // Added on 24
    private int activeBoard = 0; // Player 0, AI 1

    Random rand = new Random();

    public GuessWho() {

        Person[] characters = fm.getCharactersInArray();

        boards[0] = new Board(characters);

        // You might shuffle the character list if you want to
        // for (int i = 0; i < characters.length; i++) {
        //     int randomIndexToSwap = rand.nextInt(characters.length);
		// 	int var = characters[randomIndexToSwap];
		// 	characters[randomIndexToSwap] = characters[i];
		// 	characters[i] = temp;
		// }
        // }
        //
        
        boards[1] = new Board(characters); 
    }

    // Added on 24

    public Board[] getBoardsForUI(){
        return boards;
    }

    public void questioning(Attribute attribute) {

        boards[activeBoard].FlipDownPeopleWithoutAttribute(attribute);

        // Players swapping turns
        if (activeBoard == 0) {
            activeBoard = 1;
        }
        else{
            activeBoard = 0;
        }

        // Might be a good idea to call the AI for question as well if this was the players turn

        if (activeBoard != 0) {
            return;
        }

        //questioning([MethodCallingThatAsksTheAIForAnAttributeAsAReturn]]);
        questioning(ai.getAttribute(boards[1]));
    }
}