package GuessWho;

public class AI {

    public Attribute getAttribute(Board board){

        int[] attributeCounts = new int[Attribute.values().length];

        int numberOfActiveFlips = 0;

        // This should how many times the different attributes appear between the active people
        for (Flip f : board.getFlips()) {

            if(f.getIsActive() == false) continue;

            numberOfActiveFlips++;

            for (Attribute a : f.getPerson().getAttributes()) {
                attributeCounts[Arrays.asList(Attribute.values()).indexOf(a)]++;
            }
        }

        // This should be getting the attribute closest to 50%
        for (int i = 0; i < numberOfActiveFlips/2; i++) {
            for (int j = 0; j < attributeCounts.length; j++) {
                if((attributeCounts[j] + i == numberOfActiveFlips/2) || (attributeCounts[j] - i == numberOfActiveFlips/2)){
                    return Attribute.values()[i];
                }
            }
        }
        // If something goes wrong (the code should not reach here)
        return Attribute.NOTSET;
    }
}