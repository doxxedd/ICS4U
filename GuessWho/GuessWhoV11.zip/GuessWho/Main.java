package GuessWho;

public class Main {
    public static void main(String[] args) throws Exception {
        boolean loop = true;
        UsernameGUI gui = new UsernameGUI();
        while(loop){
            System.out.print("");
            if(!gui.getUsername().equals("")){
                loop = false;
            }
        }
        String username = gui.getUsername();
        gui.setVisible(false);
        gui = null;

        GuessWhoGUI guessWhoGUI = new GuessWhoGUI(username);
    }
}