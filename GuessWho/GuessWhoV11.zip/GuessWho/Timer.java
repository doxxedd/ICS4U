/*
* Author: Daniel.D, Lucas.C, Lucas.S
* Date: 25-01-2021
* Description:
*/
package GuessWho;

import java.time.LocalTime;
import static java.time.temporal.ChronoUnit.MINUTES;
import static java.time.temporal.ChronoUnit.SECONDS;

public class Timer {
    LocalTime startTime;

    public Timer() {
        startTime = LocalTime.now();
    }

    public String getElapsedTime(){
        return MINUTES.between(startTime, LocalTime.now()) + ":" + (SECONDS.between(startTime, LocalTime.now()) - MINUTES.between(startTime, LocalTime.now())*60);
    }
}
