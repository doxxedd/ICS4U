package GuessWho;

public class ScoreRecord {
    public String name;
    public String time;
    public int guessCount;

    public ScoreRecord(String name, String time, int guessCount) {
        this.name = name;
        this.time = time;
        this.guessCount = guessCount;
    }
}
