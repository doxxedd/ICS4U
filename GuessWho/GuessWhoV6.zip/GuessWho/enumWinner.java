package GuessWho;

//an enum that represents who won
enum enumWinner {
    PLAYER,
    AI,
    NONE;
}
