package GuessWho;

//takes in the enumWinner and ScoreRecord and returns the updated status of the game
public class GameState {
    enumWinner winner;
    ScoreRecord scoreRecord;
    Attribute AIsGuess;

    public GameState(Attribute AIsGuess, enumWinner winner, ScoreRecord scoreRecord) {
        this.AIsGuess = AIsGuess;
        this.winner = winner;
        this.scoreRecord = scoreRecord;
    }
}
