package GuessWho;

public class Board {

    //a board contains 24 flips
    private Flip[] flips = new Flip[24];

    //contains a selected character
    private Attribute selectedPerson;
    
    //puts all characters into an array of flips
    public Board(Person[] characters, Attribute selectedPerson) {

        this.selectedPerson = selectedPerson; 

        for(int i = 0; i < 24; i ++) {
            flips[i] = new Flip(characters[i]);
        }
    }

    //eliminates the flips that should be inactive after a certain question is asked
    public void flipDownPeopleWithoutAttributeAsked(Attribute attribute){
        for (Flip f : flips) {
            f.flipDownIfHasAttribute(attribute);
        }
    }

    //getter method of the status of all the flips on the board
    public Flip[] getFlips(){
        return flips;
    }

    //getter method of the selected person
    public Attribute getSelectedPerson(){
        return selectedPerson;
    }
}