package GuessWho;

enum  enumLipSize {
    SMALL,
    BIG,
    NOTSET;
}