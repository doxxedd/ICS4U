package GuessWho;

enum enumHairType {
    CURLY,
    STRAIGHT,
    LONG_AND_STRAIGHT,
    SHORT_AND_STRAIGHT,
    PARTIALLY_BALD,
    NOTSET;
}
