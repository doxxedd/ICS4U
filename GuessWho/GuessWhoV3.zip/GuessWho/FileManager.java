package GuessWho;

import java.io.*;
import java.util.*; // Just if you wanna use arraylists (doable with array, but it's a pain)
                    // TODO: Delete this comment after overview. Talking about:GetPersons method/persons array

public class FileManager {

    private String filePath;

    public FileManager(String filePath) {
        this.filePath = filePath;
    }
 
    private String[] loadDataFromFile() throws Exception {

        String[] rawDataArray = new String[24];

        File file = new File(this.filePath);
        Scanner fileInput = new Scanner(file);

        while(fileInput.hasNext()) {
            for (int i = 0; i < rawDataArray.length; i++) {
                rawDataArray[i] = fileInput.nextLine();
            }
        }

        fileInput.close();

        return rawDataArray;
    }

    // Example:nameOfPerson;5;2;10;3;1;
    public Person[] getCharactersInArray() throws Exception {

        var rawData = loadDataFromFile();

        ArrayList<Person> characters = new ArrayList<Person>();

        for (String personAttributesInString : rawData) {

            String[] nameAndAttributesList = personAttributesInString.split(";");

            List<Attribute> attributes = new ArrayList<Attribute>();

            for (int i = 1; i < nameAndAttributesList.length; i++) {
                attributes.add(Attribute.values()[Integer.parseInt(nameAndAttributesList[i])]);
            }

            characters.add(new Person(Attribute.valueOf(nameAndAttributesList[0].toUpperCase()), attributes));
        }

        // Converting the persons list to array before returning
        return characters.toArray(new Person[characters.size()]);
    }
}