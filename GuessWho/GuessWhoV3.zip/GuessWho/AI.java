package GuessWho;

import java.util.*;

public class AI {

    public Attribute getAttribute(Board board){

        int[] attributeCounts = new int[Attribute.values().length];

        List<Flip> activeFlips = new ArrayList<Flip>();

        // Getting all the active flips
        for (Flip f : board.getFlips()) {
            if(f.getIsActive() == false) continue;
            activeFlips.add(f);
        }

        // If there are less than 4 active flips, the AI will guess the name of one of the active flips
        if (activeFlips.size() < 4) {
            Random randGen = new Random();
            return activeFlips.get(randGen.nextInt(activeFlips.size())).getPerson().getName();
        }
        
        // This should get how many times the different attributes appear
        for (Flip f : activeFlips) {
            for (Attribute a : f.getPerson().getAttributes()) {
                attributeCounts[Arrays.asList(Attribute.values()).indexOf(a)]++;
            }
        }
        
        // This should be getting the attribute closest to 50%
        for (int i = 0; i < activeFlips.size()/2; i++) {
            for (int j = 0; j < attributeCounts.length; j++) {
                if((attributeCounts[j] + i == activeFlips.size()/2) || (attributeCounts[j] - i == activeFlips.size()/2)){
                    return Attribute.values()[i];
                }
            }
        }
        // If something goes wrong (the code should not reach here)
        return Attribute.NOTSET;
    }
}