package GuessWho;

public class Board {

    private Flip[] flips = new Flip[24];

    private Attribute selectedPerson;
    
    public Board(Person[] characters, Attribute selectedPerson) {

        this.selectedPerson = selectedPerson; 

        for(int i = 0; i < 24; i ++) {
            flips[i] = new Flip(characters[i]);
        }
    }


    // Added on 24
    public void flipDownPeopleWithoutAttribute(Attribute attribute){
        for (Flip f : flips) {
            f.flipDownIfHasAttribute(attribute);
        }
    }

    public Flip[] getFlips(){
        return flips;
    }

    public Attribute getSelectedPerson(){
        return selectedPerson;
    }
}