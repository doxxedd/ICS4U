package GuessWho;

import java.util.*;

import javax.xml.stream.events.Characters;

public class GuessWho {
    //declare Arrays
    private Board[] boards;
    private AI ai = new AI();
    private FileManager fm = new FileManager("GuessWhoFile.txt");

    // Added on 24
    private int activeBoard = 0; // Player 0, AI 1

    Random rand = new Random();

    public GuessWho() throws Exception {

        Random randGen = new Random();

        Person[] characters = fm.getCharactersInArray();

        boards[0] = new Board(characters, Attribute.values()[randGen.nextInt(44) + 21]);

        // Shuffling starts
        List<Person> charactersInList = Arrays.asList(characters);
        Collections.shuffle(charactersInList);
        characters = charactersInList.toArray(characters);
        // Shuffling ends

        boards[1] = new Board(characters, Attribute.values()[randGen.nextInt(44) + 21]); 
    }

    // Added on 24

    public Board[] getBoardsForUI(){
        return boards;
    }

    public void questioning(Attribute attribute) {

        if (attribute.ordinal() > 20) {
            if (activeBoard == 0) {
                if (boards[1].getSelectedPerson() == attribute) {
                    // TODO: Game end with player winning
                }
                else{
                    for (Flip f : boards[0].getFlips()) {
                        if(f.getPerson().getName() == attribute){
                            f.flipDown();
                            break;
                        }
                    }
                }
            }
            else{
                if (boards[0].getSelectedPerson() == attribute) {
                    // TODO: Game end with AI winning
                }
                else{
                    for (Flip f : boards[1].getFlips()) {
                        if(f.getPerson().getName() == attribute){
                            f.flipDown();
                            break;
                        }
                    }
                }
            }
            return;
        }

        boards[activeBoard].flipDownPeopleWithoutAttribute(attribute);

        // Players swapping turns
        if (activeBoard == 0) {
            activeBoard = 1;
        }
        else{
            activeBoard = 0;
        }

        // Might be a good idea to call the AI for question as well if this was the players turn

        if (activeBoard != 0) {
            return;
        }

        //questioning([MethodCallingThatAsksTheAIForAnAttributeAsAReturn]]);
        questioning(ai.getAttribute(boards[1]));
    }
}