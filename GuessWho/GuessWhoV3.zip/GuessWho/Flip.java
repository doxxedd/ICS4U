package GuessWho;

public class Flip{
	private boolean isActive = true;
	private Person person;

    public Flip (Person person) {
        this.person = person;
    }

    public boolean getIsActive() {
        return isActive;
    }

    public Person getPerson() {
        return person;
    }

    public void flipDown(){
        this.isActive = false;
    }

    // Added on 24
    public void flipDownIfHasAttribute(Attribute attribute){
        if (this.person.hasAttribute(attribute)) {
            isActive = false;
        }
    }
}
