package GuessWho;

import java.util.Arrays;

public class Tester {
    public static void main(String[] args) throws Exception {

        //TestFileManager();
        //TestPerson();
        //TestFlip();
        //TestBoard();
        TestAI();
    }

    private static void TestFileManager() throws Exception{
        FileManager fm = new FileManager("GuessWhoFile.txt");
        for (Person p : fm.getCharactersInArray()) {
            System.out.println("\n" + p.getName() + ":");
            for (Attribute a : p.getAttributes()) {
                System.out.println(a);
            }
        }
    }

    private static void TestPerson(){
        Person p = new Person(Attribute.ALEJANDRO, Arrays.asList(new Attribute[]{Attribute.BEARD, Attribute.BROWN_EYES, Attribute.BIG_LIPS}));
        System.out.println("(getName)       Should be ALEJANDRO: " + p.getName());
        System.out.println("(hasAttribute)  Should be true:" + p.hasAttribute(Attribute.BEARD));
        System.out.println("(hasAttribute)  Should be false:" + p.hasAttribute(Attribute.SMALL_LIPS));
    }

    private static void TestFlip(){
        Flip f = new Flip(new Person(Attribute.ALEJANDRO, Arrays.asList(new Attribute[]{Attribute.BEARD, Attribute.BROWN_EYES, Attribute.BIG_LIPS})));
        System.out.println("(getIsActive)               Should be active:" + f.getIsActive());
        f.flipDown();
        System.out.println("(flipDown)                  Should not be active:" + f.getIsActive());
        f = new Flip(new Person(Attribute.ALEJANDRO, Arrays.asList(new Attribute[]{Attribute.BEARD, Attribute.BROWN_EYES, Attribute.BIG_LIPS})));
        f.flipDownIfHasAttribute(Attribute.ALEJANDRO);
        System.out.println("(flipDownIfHasAttribute)    Should be active:" + f.getIsActive());
        f.flipDownIfHasAttribute(Attribute.BEARD);
        System.out.println("(flipDownIfHasAttribute)    Should not be active:" + f.getIsActive());
    }

    private static void TestBoard() {
        Board b = new Board(new Person[]{
            new Person(Attribute.ALEJANDRO, Arrays.asList(new Attribute[]{Attribute.BEARD, Attribute.BROWN_EYES, Attribute.BIG_LIPS})),
            new Person(Attribute.MARIA, Arrays.asList(new Attribute[]{Attribute.BROWN_HAIR, Attribute.SMALL_LIPS, Attribute.FEMALE})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.BIG_LIPS, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
            new Person(Attribute.ANITA, Arrays.asList(new Attribute[]{Attribute.MUSTACHE, Attribute.HAT, Attribute.GLASSES, Attribute.BEARD})),
             }, Attribute.ALEJANDRO);
        b.flipDownPeopleWithoutAttribute(Attribute.MUSTACHE);
        System.out.println("(flipDownPeopleWithoutAttribute) Should be only 3 people active:");
        for (Flip f : b.getFlips()) {
            System.out.println(f.getIsActive() + ":" + f.getPerson().getName());
        }
    }
    
    private static void TestAI() {
        
    }
}
